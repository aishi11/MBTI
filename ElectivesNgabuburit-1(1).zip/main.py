import time
import os

# ------------ Additional : Fungsi-fungsi gimmick :D -------------------
# Fungsi untuk animasi loading
def loading_animation():
  # Define the animation characters
  animation_chars = ['|', '/', '-', '\\']

  # Display the loading animation
  for _ in range(3):  # Adjust the range for desired duration
    for char in animation_chars:
      print(f'\rLoading {char}', end='', flush=True)
      time.sleep(0.1)  # Adjust the sleep time for desired speed

  print('\r', end='', flush=True)  # Clear the loading animation


# Fungsi untuk clear screen
def clear_screen():
  # Clear the screen based on the OS
  time.sleep(1)
  os.system('cls' if os.name == 'nt' else 'clear')


# Definisikan variabel fungsi kognitif untuk menampung bobot jawaban
tiList = []
niList = []
siList = []
fiList = []
seList = []
feList = []
teList = []
neList = []


# --------- Membuat fungsi-fungsi yang dibutuhkan -----------
# Fungsi pertanyaan
def pertanyaan1():
  print("Bagaimana temanmu mendeskripsikan kamu?")
  print("A. Hangat, empati, ramah")
  print("B. Mengintimidasi, langsung, blak-blakan")
  print("C. Aktif, seru, waspada")
  print("D. Gila, kreatif, gampang terpecah fokusnya")
  print("Type your answer : ")

  # Tulis kodemu di bawah ini supaya dapat menerima input dan menampilkan animasi loading!
  ans1 = input()

  #menambahkan skor dari jawaban pertanyaan 1
  match ans1:
    case 'a' | 'A':
      tiList.append(1.5)
    case 'b' | 'B':
      neList.append(1.5)
    case 'c' | 'C':
      teList.append(1.5)
    case 'd' | 'D':
      seList.append(1.5)
    case default:
      return 0
  loading_animation()
  print("Jawaban sudah tersimpan!")
  clear_screen()


def pertanyaan2():
  print("Bagaimana kamu memecahkan suatu masalah?")
  print("A. Aku melakukan apa yang menurutku benar")
  print("B. Aku melakukan apa yang tampaknya paling logis")
  print(
      "C. Aku membandingkannya dengan pengalaman masa laluku dan melakukan apa yang berhasil sebelumnya"
  )
  print("D. Aku mengikuti instingku")
  print("Type your answer: ")

  # Tulis kodemu di bawah ini supaya dapat menerima input dan menampilkan animasi loading!

  ans2 = input()
  match ans2:
    case 'a' | 'A':
      fiList.append(1.3)
    case 'b' | 'B':
      tiList.append(1.3)
    case 'c' | 'C':
      siList.append(1.3)
    case 'd' | 'D':
      niList.append(1.3)
    case default:
      0
  loading_animation()
  print("Jawaban sudah tersimpan!")
  clear_screen()


def pertanyaan3():
  print("Bagaimana kamu akan membuat keputusan penting dalam hidup?")
  print("A. Aku melakukan apa yang paling masuk akal bagi diriku sendiri")
  print("B. Aku membuat daftar pro/kontra dan memutuskan mana yang terbaik")
  print(
      "C. Aku memikirkan bagaimana hal ini akan berdampak pada orang lain dan juga diri Aku sendiri"
  )
  print("D. Aku memilih apa yang membuat Aku paling bahagia")

  # Tulis kodemu di bawah ini supaya dapat menerima input dan menampilkan animasi loading!

  ans3 = input()
  match ans3:
    case 'a' | 'A':
      fiList.append(1.6)
    case 'b' | 'B':
      tiList.append(1.6)
    case 'c' | 'C':
      feList.append(1.6)
    case 'd' | 'D':
      teList.append(1.6)
    case default:
      0

  loading_animation()
  print("Jawaban sudah tersimpan!")
  clear_screen()


def pertanyaan4():
  print(
      "Bayangkan Anda sedang berjalan-jalan dengan teman-teman. Yang mana yang paling menggambarkan dirimu?"
  )
  print(
      "A. Saya mengakar apa yang telah berubah dan memikirkan yang terakhir kali"
  )
  print(
      "B. Saya sepenuhnya diperbolehkan berada di sekitar saya, menunjukkan berbagai hal"
  )
  print(
      "C. Perhatian saya mudah teralihkan dan cenderung membicarakan hal-hal sembarangan"
  )
  print("D. Pikiranku ada di tempat lain")
  print("Type your answer: ")

  # Tulis kodemu di bawah ini supaya dapat menerima input dan menampilkan animasi loading!

  ans4 = input()
  match ans4:
    case 'a' | 'A':
      siList.append(1.1)
    case 'b' | 'B':
      seList.append(1.1)
    case 'c' | 'C':
      neList.append(1.1)
    case 'd' | 'D':
      niList.append(1.1)
    case default:
      0
  loading_animation()
  print("Jawaban sudah tersimpan!")
  clear_screen()


def pertanyaan5():
  print("Apa yang lebih mungkin Anda pesan di restoran favorit Anda?")
  print(
      "A. Saya punya 'menu biasa' atau menu andalan yang saya pesan setiap saat"
  )
  print(
      "B. Saya suka mencoba hal-hal baru dan biasanya mendapatkan sesuatu yang baru setiap saat"
  )
  print("Type your answer here: ")

  # Tulis kodemu di bawah ini supaya dapat menerima input dan menampilkan animasi loading!

  ans5 = input()
  match ans5:
    case 'a' | 'A':
      siList.append(1.4)
    case 'b' | 'B':
      seList.append(1.4)
    case default:
      0
  loading_animation()
  print("Jawaban sudah tersimpan!")
  clear_screen()


def pertanyaan6():
  print(
      "Apakah kamu lebih selaras dengan perasaanmu sendiri atau perasaan orang lain?"
  )
  print(
      "A.Perasaan saya sendiri. Penting bagi saya untuk merefleksikan perasaan saya terhadap segala hal"
  )
  print(
      "B.Perasaan orang lain. Saya dapat dengan mudah bersimpati dengan orang lain"
  )
  print("Type your answer: ")

  # Tulis kodemu di bawah ini supaya dapat menerima input dan menampilkan animasi loading!

  ans6 = input()
  match ans6:
    case 'a' | 'A':
      fiList.append(1)
    case 'b' | 'B':
      feList.append(1)
    case default:
      0
  loading_animation()
  print("Jawaban sudah tersimpan!")
  clear_screen()


def pertanyaan7():
  print("Pilihlah pernyataan yang lebih menggambarkan diri Anda")
  print("A. Saya menyatukan ide-ide saya untuk menciptakan produk jadi")
  print(
      "B. Saya mempunyai begitu banyak ide sehingga saya biasanya tidak menyelesaikan proyek"
  )
  print("Type ur answer: ")

  # Tulis kodemu di bawah ini supaya dapat menerima input dan menampilkan animasi loading!

  ans7 = input()
  match ans7:
    case 'a' | 'A':
      niList.append(0.7)
    case 'b' | 'B':
      neList.append(0.7)
    case default:
      0
  loading_animation()
  print("Jawaban sudah tersimpan!")
  clear_screen()


def pertanyaan8():
  print("Apa yang ingin Anda pelajari?")
  print(
      "A. Saya senang mempelajari hal-hal yang saya minati, meskipun saya tidak akan menerapkannya dalam kehidupan saya"
  )
  print(
      "B. Saya lebih suka belajar tentang sesuatu yang berhubungan dengan tujuan saya/praktis dalam hidup"
  )
  print("Type ur answer: ")

  # Tulis kodemu di bawah ini supaya dapat menerima input dan menampilkan animasi loading!

  ans8 = input()
  match ans8:
    case 'a' | 'A':
      tiList.append(0.5)
    case 'b' | 'B':
      teList.append(0.5)
    case default:
      0
  loading_animation()
  print("Jawaban sudah tersimpan!")
  clear_screen()


# Fungsi perhitungan total skor
def calculate():
  Fe = sum(feList)
  Te = sum(teList)
  Se = sum(seList)
  Ne = sum(neList)
  Fi = sum(fiList)
  Ni = sum(niList)
  Si = sum(siList)
  Ti = sum(tiList)
  yourType = None

  if (Te > Fe and Te > Ne and Te > Se):
    if (Si > Te and Si > Ni):
      yourType = "ISTJ"
    elif (Ni > Te and Ni > Si):
      yourType = "INTJ"
    elif ((Si > Ni)):
      yourType = "ESTJ"
    elif ((Ni > Si)):
      yourType = "ENTJ"
  elif (Fe > Te and Fe > Se and Fe > Ne):
    if (Si > Fe and Si > Ni):
      yourType = "ISFJ"
    elif (Ni > Fe and Ni > Si):
      yourType = "INFJ"
    elif ((Si > Ni)):
      yourType = "ESFJ"
    elif ((Ni > Si)):
      yourType = "ENFJ"
  elif (Ne > Te and Ne > Se and Ne > Fe):
    if (Ti > Ne and Ti > Fi):
      yourType = "INTP"
    elif (Fi > Ne and Fi > Ti):
      yourType = "INFP"
    elif ((Ti > Fi)):
      yourType = "ENTP"
    elif ((Fi > Ti)):
      yourType = "ENFP"
  elif (Se > Te and Se > Fe and Se > Ne):
    if (Ti > Se and Ti > Fi):
      yourType = "ISTP"
    elif (Fi > Se and Fi > Ti):
      yourType = "ISFP"
    elif ((Ti > Fi)):
      yourType = "ESTP"
    elif ((Fi > Ti)):
      yourType = "ESFP"

  return yourType


# Fungsi reset angka perhitungan
def resetAll():
  yourType = ""
  Fe = 0
  Te = 0
  Ne = 0
  Se = 0
  Fi = 0
  Ti = 0
  Si = 0
  Ni = 0
  lst = [feList, fiList, neList, niList, seList, siList, teList, tiList]
  for a in range(len(lst)):
    lst[a].clear()


# ---------- Fungsi Utama ------------


def main():
  print("======== MBTI TEST =======")
  print("Selamat datang di test MBTI!")
  print("Apakah kamu siap untuk mengikuti tes? Y/N")
  siap = input()
  while (siap == 'Y'):
    print("---- Pertanyaan 1 ----")
    pertanyaan1()
    print("---- Pertanyaan 2 ----")
    pertanyaan2()
    print("---- Pertanyaan 3 ----")
    pertanyaan3()
    print("---- Pertanyaan 4 ----")
    pertanyaan4()
    print("---- Pertanyaan 5 ----")
    pertanyaan5()
    print("---- Pertanyaan 6 ----")
    pertanyaan6()
    print("---- Pertanyaan 7 ----")
    pertanyaan7()
    print("---- Pertanyaan 8 ----")
    pertanyaan8()
    print("Berdasarkan hasil tes, tipe kepribadian MBTI-mu: ", calculate())

    print("Apakah kamu ingin mengikuti tes lagi? Y/N")
    siap = input()
    resetAll()
    clear_screen()

  print("Thank youuu <3")


# ------------ Tes Kriuk -------------------
main()
